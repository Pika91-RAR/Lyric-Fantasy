package com.lyicfantasy.command;

import com.lyicfantasy.config.LyicConfig;
import com.lyicfantasy.lyrics.LyricsManager;
import com.lyicfantasy.media.MediaManager;
import com.lyicfantasy.media.TrackInfo;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;

/** /lyic offset <ms> | mode <modo> | reload | status */
public final class LyicCommand {

    private LyicCommand() {
    }

    public static void register(RegisterClientCommandsEvent e) {
        LiteralArgumentBuilder<CommandSourceStack> mode = Commands.literal("mode");
        for (LyicConfig.Mode m : LyicConfig.Mode.values()) {
            mode.then(Commands.literal(m.name().toLowerCase()).executes(c -> {
                LyicConfig.MODE.set(m);
                LyicConfig.save();
                c.getSource().sendSuccess(() -> Component.translatable("lyicfantasy.msg.mode", m.name()), false);
                return 1;
            }));
        }

        e.getDispatcher().register(Commands.literal("lyic")
                .then(Commands.literal("offset")
                        .then(Commands.argument("ms", IntegerArgumentType.integer(-5000, 5000)).executes(c -> {
                            int v = IntegerArgumentType.getInteger(c, "ms");
                            LyicConfig.OFFSET_MS.set(v);
                            LyicConfig.save();
                            c.getSource().sendSuccess(() -> Component.translatable("lyicfantasy.msg.offset", v), false);
                            return 1;
                        })))
                .then(mode)
                .then(Commands.literal("reload").executes(c -> {
                    LyricsManager.get().reload();
                    c.getSource().sendSuccess(() -> Component.literal("Lyic Fantasy: buscando la letra de nuevo..."), false);
                    return 1;
                }))
                .then(Commands.literal("status").executes(c -> {
                    TrackInfo t = MediaManager.get().track();
                    String msg = t == null
                            ? "Sin música detectada (proveedor: " + MediaManager.get().providerName() + ")"
                            : t.title() + " - " + t.artist() + " | " + (t.playing() ? "sonando" : "en pausa")
                            + " | " + MediaManager.get().positionMs() / 1000 + "s"
                            + " | letra: " + LyricsManager.get().state()
                            + " | proveedor: " + MediaManager.get().providerName();
                    c.getSource().sendSuccess(() -> Component.literal(msg), false);
                    return 1;
                })));
    }
}
