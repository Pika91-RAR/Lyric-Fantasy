package com.lyicfantasy.media;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lyicfantasy.LyicFantasy;
import net.neoforged.fml.loading.FMLPaths;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.function.Consumer;

/**
 * Windows: lee el "Now Playing" del sistema (SMTC) con un script de PowerShell que emite una línea JSON
 * cada ~400 ms. Cubre Spotify, YouTube Music y cualquier navegador/reproductor que use la sesión multimedia.
 */
public final class WindowsSmtcProvider implements MediaProvider {

    private volatile boolean running;
    private volatile Process process;
    private Thread thread;

    @Override
    public String name() {
        return "windows-smtc";
    }

    @Override
    public void start(Consumer<TrackInfo> sink) {
        running = true;
        thread = new Thread(() -> loop(sink), "LyicFantasy-SMTC");
        thread.setDaemon(true);
        thread.start();
    }

    @Override
    public void stop() {
        running = false;
        Process p = process;
        if (p != null) {
            p.destroyForcibly();
        }
    }

    private void loop(Consumer<TrackInfo> sink) {
        while (running) {
            try {
                Path script = extractScript();
                ProcessBuilder pb = new ProcessBuilder(
                        "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                        "-File", script.toString(), "-ParentPid", String.valueOf(ProcessHandle.current().pid()));
                pb.redirectError(ProcessBuilder.Redirect.DISCARD);
                process = pb.start();
                try (BufferedReader r = new BufferedReader(
                        new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while (running && (line = r.readLine()) != null) {
                        handle(line, sink);
                    }
                }
            } catch (Exception e) {
                LyicFantasy.LOGGER.warn("[LyicFantasy] SMTC: {}", e.toString());
            } finally {
                Process p = process;
                if (p != null) {
                    p.destroyForcibly();
                }
                sink.accept(null);
            }
            sleep(3000); // reintento si el proceso muere
        }
    }

    private void handle(String line, Consumer<TrackInfo> sink) {
        line = line.strip();
        if (line.startsWith("\uFEFF")) {
            line = line.substring(1);
        }
        if (line.isEmpty() || line.charAt(0) != '{') {
            return;
        }
        try {
            JsonObject o = JsonParser.parseString(line).getAsJsonObject();
            if (o.has("none")) {
                sink.accept(null);
                return;
            }
            sink.accept(new TrackInfo(
                    str(o, "title"), str(o, "artist"), str(o, "album"),
                    (long) num(o, "dur"), (long) num(o, "pos"),
                    o.has("playing") && o.get("playing").getAsBoolean(),
                    System.nanoTime(), str(o, "app")));
        } catch (Exception ignored) {
            // línea corrupta: se ignora
        }
    }

    private static String str(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
    }

    private static double num(JsonObject o, String k) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsDouble() : 0;
    }

    private Path extractScript() throws Exception {
        Path dir = FMLPaths.CONFIGDIR.get().resolve("lyicfantasy");
        Files.createDirectories(dir);
        Path target = dir.resolve("smtc.ps1");
        try (InputStream in = WindowsSmtcProvider.class.getResourceAsStream("/lyicfantasy/smtc.ps1")) {
            if (in == null) {
                throw new IllegalStateException("smtc.ps1 no está en el JAR");
            }
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }
        return target;
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
