package com.lyicfantasy.media;

import java.util.function.Consumer;

/** Fuente de "ahora suena" dependiente del sistema operativo. */
public interface MediaProvider {

    String name();

    /** Arranca en hilos de fondo. {@code sink} recibe null cuando no hay nada sonando. */
    void start(Consumer<TrackInfo> sink);

    void stop();
}
