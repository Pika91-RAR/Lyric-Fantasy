package com.lyicfantasy.media;

import com.lyicfantasy.LyicFantasy;

import java.util.Locale;

/**
 * Recibe muestras de "ahora suena" del proveedor del sistema y las convierte en una posición
 * suave: interpola con el reloj local entre muestras y corrige el desfase poco a poco.
 */
public final class MediaManager {

    private static final MediaManager INSTANCE = new MediaManager();
    private static final long STALE_NANOS = 8_000_000_000L;

    public static MediaManager get() {
        return INSTANCE;
    }

    private MediaProvider provider;
    private boolean started;

    private TrackInfo latest;
    private long lastSampleNanos;
    private long anchorPosMs;
    private long anchorNanos;
    private boolean playing;

    private MediaManager() {
    }

    public synchronized void start() {
        if (started) {
            return;
        }
        started = true;
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("win")) {
            provider = new WindowsSmtcProvider();
        } else if (os.contains("linux")) {
            provider = new LinuxPlayerctlProvider();
        } else {
            LyicFantasy.LOGGER.warn("[LyicFantasy] Sistema '{}' sin proveedor de música todavía.", os);
            return;
        }
        LyicFantasy.LOGGER.info("[LyicFantasy] Proveedor de música: {}", provider.name());
        provider.start(this::onSample);
        Runtime.getRuntime().addShutdownHook(new Thread(this::stop, "LyicFantasy-Shutdown"));
    }

    public synchronized void stop() {
        if (provider != null) {
            provider.stop();
        }
        started = false;
    }

    public String providerName() {
        return provider == null ? "none" : provider.name();
    }

    private synchronized void onSample(TrackInfo t) {
        if (t == null || !t.valid()) {
            latest = null;
            return;
        }
        long at = t.sampleNanos();
        boolean sameTrack = latest != null && latest.key().equals(t.key());
        if (sameTrack && playing && t.playing()) {
            long predicted = anchorPosMs + (at - anchorNanos) / 1_000_000L;
            long diff = t.positionMs() - predicted;
            if (Math.abs(diff) < 400) {
                anchorPosMs = predicted + diff / 4; // corrección suave, sin saltos visibles
            } else {
                anchorPosMs = t.positionMs();      // seek real
            }
        } else {
            anchorPosMs = t.positionMs();
        }
        anchorNanos = at;
        playing = t.playing();
        latest = t;
        lastSampleNanos = at;
    }

    /** Pista actual o null si no hay nada sonando / los datos están obsoletos. */
    public synchronized TrackInfo track() {
        if (latest == null || System.nanoTime() - lastSampleNanos > STALE_NANOS) {
            return null;
        }
        return latest;
    }

    public synchronized boolean isPlaying() {
        return latest != null && playing;
    }

    /** Posición interpolada en ms (sin offset del usuario). */
    public synchronized long positionMs() {
        if (latest == null) {
            return 0;
        }
        long pos = playing ? anchorPosMs + (System.nanoTime() - anchorNanos) / 1_000_000L : anchorPosMs;
        long dur = latest.durationMs();
        if (dur > 0 && pos > dur) {
            pos = dur;
        }
        return Math.max(0, pos);
    }
}
