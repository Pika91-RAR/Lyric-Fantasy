package com.lyicfantasy.media;

import com.lyicfantasy.LyicFantasy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** Linux (experimental): MPRIS a través de la herramienta {@code playerctl} (apt/pacman install playerctl). */
public final class LinuxPlayerctlProvider implements MediaProvider {

    private volatile boolean running;
    private Thread thread;

    @Override
    public String name() {
        return "linux-playerctl";
    }

    @Override
    public void start(Consumer<TrackInfo> sink) {
        running = true;
        thread = new Thread(() -> loop(sink), "LyicFantasy-MPRIS");
        thread.setDaemon(true);
        thread.start();
    }

    @Override
    public void stop() {
        running = false;
    }

    private void loop(Consumer<TrackInfo> sink) {
        boolean warned = false;
        while (running) {
            try {
                String meta = run(List.of("playerctl", "metadata", "--format",
                        "{{status}}\t{{title}}\t{{artist}}\t{{album}}\t{{mpris:length}}"));
                if (meta == null || meta.isBlank()) {
                    sink.accept(null);
                } else {
                    String[] p = meta.split("\t", -1);
                    String pos = run(List.of("playerctl", "position"));
                    long posMs = pos == null || pos.isBlank() ? 0 : (long) (Double.parseDouble(pos.strip()) * 1000.0);
                    long durMs = p.length > 4 && !p[4].isBlank() ? Long.parseLong(p[4].strip()) / 1000L : 0L;
                    sink.accept(new TrackInfo(p.length > 1 ? p[1] : "", p.length > 2 ? p[2] : "",
                            p.length > 3 ? p[3] : "", durMs, posMs,
                            "Playing".equalsIgnoreCase(p[0].strip()), System.nanoTime(), "mpris"));
                }
            } catch (IOException e) {
                if (!warned) {
                    LyicFantasy.LOGGER.warn("[LyicFantasy] 'playerctl' no está instalado; sin música en Linux.");
                    warned = true;
                }
                sink.accept(null);
                sleep(10_000);
            } catch (Exception e) {
                sink.accept(null);
            }
            sleep(700);
        }
    }

    private static String run(List<String> cmd) throws IOException, InterruptedException {
        Process p = new ProcessBuilder(cmd).redirectErrorStream(false)
                .redirectError(ProcessBuilder.Redirect.DISCARD).start();
        String out;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            out = r.readLine();
        }
        if (!p.waitFor(1500, TimeUnit.MILLISECONDS)) {
            p.destroyForcibly();
            return null;
        }
        return p.exitValue() == 0 ? out : null;
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
