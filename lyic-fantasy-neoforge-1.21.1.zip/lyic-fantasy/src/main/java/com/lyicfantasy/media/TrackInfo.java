package com.lyicfantasy.media;

/**
 * Muestra de "ahora suena". {@code positionMs} es la posición estimada en el instante {@code sampleNanos}
 * (System.nanoTime), así que el consumidor puede interpolar.
 */
public record TrackInfo(String title, String artist, String album, long durationMs,
                        long positionMs, boolean playing, long sampleNanos, String source) {

    public boolean valid() {
        return title != null && !title.isBlank();
    }

    /** Identidad de la canción (no incluye posición ni estado de reproducción). */
    public String key() {
        return (artist == null ? "" : artist.toLowerCase()) + "|" + (title == null ? "" : title.toLowerCase());
    }
}
