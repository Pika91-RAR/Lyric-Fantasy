package com.lyicfantasy;

import com.lyicfantasy.command.LyicCommand;
import com.lyicfantasy.config.LyicConfig;
import com.lyicfantasy.input.Keybinds;
import com.lyicfantasy.media.MediaManager;
import com.lyicfantasy.render.HudLyricsLayer;
import com.lyicfantasy.render.WorldLyricsRenderer;
import com.mojang.logging.LogUtils;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

/** Lyic Fantasy: letras sincronizadas flotando en el mundo. Solo cliente: funciona en cualquier servidor. */
@Mod(value = LyicFantasy.MODID, dist = Dist.CLIENT)
public final class LyicFantasy {

    public static final String MODID = "lyicfantasy";
    public static final Logger LOGGER = LogUtils.getLogger();

    public LyicFantasy(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, LyicConfig.SPEC);
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);

        modBus.addListener(Keybinds::register);
        modBus.addListener(HudLyricsLayer::register);
        modBus.addListener((FMLClientSetupEvent e) -> e.enqueueWork(() -> MediaManager.get().start()));

        NeoForge.EVENT_BUS.addListener(WorldLyricsRenderer::onRenderLevel);
        NeoForge.EVENT_BUS.addListener(Keybinds::onClientTick);
        NeoForge.EVENT_BUS.addListener(LyicCommand::register);
    }
}
