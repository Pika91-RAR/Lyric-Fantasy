package com.lyicfantasy.lyrics;

import java.util.regex.Pattern;

/** Limpia títulos/artistas "sucios" (YouTube, remasters, feats) para mejorar la búsqueda de letras. */
public final class TitleCleaner {

    public record Cleaned(String title, String artist) {
    }

    private static final Pattern BRACKET_NOISE = Pattern.compile(
            "\\s*[(\\[][^)\\]]*(feat\\.?|ft\\.?|featuring|remaster(ed)?|live|official|video|audio|lyrics?|visuali[sz]er|version|mix|edit|explicit|hd|hq|4k)[^)\\]]*[)\\]]",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DASH_NOISE = Pattern.compile(
            "\\s+-\\s+(remaster(ed)?(\\s+\\d{4})?|\\d{4}\\s+remaster(ed)?|single version|radio edit|live.*|official.*)$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern FEAT_TAIL = Pattern.compile("\\s+(feat\\.?|ft\\.?|featuring)\\s+.*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern TOPIC = Pattern.compile("\\s*-\\s*Topic$", Pattern.CASE_INSENSITIVE);

    private TitleCleaner() {
    }

    public static Cleaned clean(String title, String artist) {
        String t = title == null ? "" : title.strip();
        String a = artist == null ? "" : artist.strip();

        a = TOPIC.matcher(a).replaceAll("");
        // Vídeos de YouTube sin artista real: "Artista - Título"
        int dash = t.indexOf(" - ");
        if (dash > 0 && (a.isEmpty() || t.toLowerCase().startsWith(a.toLowerCase() + " - "))) {
            a = t.substring(0, dash).strip();
            t = t.substring(dash + 3).strip();
        }
        t = BRACKET_NOISE.matcher(t).replaceAll("");
        t = DASH_NOISE.matcher(t).replaceAll("");
        t = FEAT_TAIL.matcher(t).replaceAll("").strip();

        // Solo el primer artista: "A, B" / "A & B" / "A feat. B"
        a = FEAT_TAIL.matcher(a).replaceAll("");
        int cut = firstSeparator(a);
        if (cut > 0) {
            a = a.substring(0, cut);
        }
        return new Cleaned(t.strip(), a.strip());
    }

    private static int firstSeparator(String a) {
        int best = -1;
        for (String sep : new String[]{",", " & ", " x ", " × ", ";"}) {
            int i = a.indexOf(sep);
            if (i > 0 && (best < 0 || i < best)) {
                best = i;
            }
        }
        return best;
    }
}
