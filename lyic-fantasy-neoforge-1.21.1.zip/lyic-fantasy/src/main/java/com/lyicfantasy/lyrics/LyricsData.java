package com.lyicfantasy.lyrics;

import java.util.List;

public record LyricsData(List<LyricLine> lines, boolean wordSynced, String source) {

    public boolean isEmpty() {
        return lines.isEmpty();
    }

    /** Índice de la última línea con startMs <= posMs, o -1 si aún no empieza la primera. */
    public int indexAt(long posMs) {
        int lo = 0, hi = lines.size() - 1, ans = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).startMs() <= posMs) {
                ans = mid;
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return ans;
    }
}
