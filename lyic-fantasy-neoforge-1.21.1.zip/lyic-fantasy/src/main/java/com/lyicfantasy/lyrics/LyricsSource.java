package com.lyicfantasy.lyrics;

import com.lyicfantasy.media.TrackInfo;

import java.util.Optional;

/** Una fuente de letras. Se prueban en cascada; la primera que devuelva letra sincronizada gana. */
public interface LyricsSource {

    String name();

    /** Bloqueante: se llama desde un hilo de fondo. */
    Optional<LyricsData> fetch(TrackInfo track) throws Exception;
}
