package com.lyicfantasy.lyrics;

import com.lyicfantasy.LyicFantasy;
import com.lyicfantasy.media.TrackInfo;
import net.neoforged.fml.loading.FMLPaths;

import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Busca, cachea y entrega la letra de la canción actual sin bloquear el hilo de render. */
public final class LyricsManager {

    public enum State { IDLE, LOADING, READY, NONE }

    private static final LyricsManager INSTANCE = new LyricsManager();

    public static LyricsManager get() {
        return INSTANCE;
    }

    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "LyicFantasy-Lyrics");
        t.setDaemon(true);
        return t;
    });
    private final LrclibSource lrclib = new LrclibSource();
    private final LyricsCache cache = new LyricsCache(FMLPaths.CONFIGDIR.get().resolve("lyicfantasy").resolve("cache"));
    private final AtomicInteger token = new AtomicInteger();

    private volatile State state = State.IDLE;
    private volatile LyricsData data;
    private volatile String currentKey;
    private volatile TrackInfo lastTrack;

    private LyricsManager() {
    }

    public State state() {
        return state;
    }

    public LyricsData data() {
        return data;
    }

    /** Llamar cada tick con la pista actual (o null). Solo actúa cuando cambia la canción. */
    public void onTrack(TrackInfo t) {
        if (t == null || !t.valid()) {
            if (currentKey != null) {
                reset();
            }
            return;
        }
        String key = t.key();
        if (key.equals(currentKey)) {
            // la duración a veces llega tarde: si aún no teníamos y ahora sí, no re-buscamos (el LRC ya trae tiempos)
            return;
        }
        load(t, key);
    }

    /** Borra la caché de la canción actual y vuelve a buscar. */
    public void reload() {
        TrackInfo t = lastTrack;
        if (t == null) {
            return;
        }
        cache.delete(t.key());
        load(t, t.key());
    }

    private void reset() {
        token.incrementAndGet();
        currentKey = null;
        lastTrack = null;
        data = null;
        state = State.IDLE;
    }

    private void load(TrackInfo t, String key) {
        int my = token.incrementAndGet();
        currentKey = key;
        lastTrack = t;
        data = null;
        state = State.LOADING;
        exec.execute(() -> {
            try {
                Optional<LyricsCache.Entry> cached = cache.read(key);
                if (cached.isPresent()) {
                    LyricsCache.Entry e = cached.get();
                    if (e.none()) {
                        finish(my, null);
                    } else {
                        finish(my, LrcParser.parse(e.lrc(), t.durationMs(), e.source()));
                    }
                    return;
                }
                Optional<LrclibSource.Found> f = lrclib.fetchRaw(t);
                if (f.isPresent()) {
                    cache.write(key, f.get().lrc(), lrclib.name());
                    finish(my, f.get().data());
                } else {
                    cache.writeNone(key);
                    finish(my, null);
                }
            } catch (Exception ex) {
                LyicFantasy.LOGGER.warn("[LyicFantasy] No se pudo obtener la letra de '{}': {}", t.title(), ex.toString());
                finish(my, null); // sin caché negativa: se reintentará al cambiar de canción o con /lyic reload
            }
        });
    }

    private void finish(int my, LyricsData d) {
        if (token.get() != my) {
            return; // llegó tarde: ya cambió la canción
        }
        if (d == null || d.isEmpty()) {
            data = null;
            state = State.NONE;
        } else {
            data = d;
            state = State.READY;
        }
    }
}
