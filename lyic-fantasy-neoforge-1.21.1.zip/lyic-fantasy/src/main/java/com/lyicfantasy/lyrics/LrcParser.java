package com.lyicfantasy.lyrics;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parser de LRC estándar ([mm:ss.xx] texto) y LRC mejorado con etiquetas por palabra
 * ([mm:ss.xx] <mm:ss.xx>palabra <mm:ss.xx>palabra). Si la letra no trae tiempos por palabra,
 * los estima repartiendo la duración de la línea según la longitud de cada palabra.
 */
public final class LrcParser {

    private static final Pattern LINE_TAG = Pattern.compile("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]");
    private static final Pattern WORD_TAG = Pattern.compile("<(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?>");

    private LrcParser() {
    }

    private record Raw(long start, String text) {
    }

    public static LyricsData parse(String lrc, long trackDurationMs, String source) {
        List<Raw> raws = new ArrayList<>();
        for (String line : lrc.split("\\R")) {
            Matcher m = LINE_TAG.matcher(line);
            List<Long> stamps = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                stamps.add(toMs(m.group(1), m.group(2), m.group(3)));
                end = m.end();
            }
            if (stamps.isEmpty()) {
                continue; // metadatos ([ar:...], [ti:...]) o líneas sin tiempo
            }
            String text = line.substring(end).strip();
            for (long s : stamps) {
                raws.add(new Raw(s, text));
            }
        }
        raws.sort(Comparator.comparingLong(Raw::start));

        List<LyricLine> out = new ArrayList<>();
        boolean anyWordSync = false;
        for (int i = 0; i < raws.size(); i++) {
            Raw r = raws.get(i);
            long lineEnd = i + 1 < raws.size()
                    ? raws.get(i + 1).start()
                    : (trackDurationMs > r.start() ? trackDurationMs : r.start() + 5000);
            if (lineEnd <= r.start()) {
                lineEnd = r.start() + 1;
            }
            LyricLine line = buildLine(r, lineEnd);
            anyWordSync |= line.wordSynced();
            out.add(line);
        }
        return new LyricsData(List.copyOf(out), anyWordSync, source);
    }

    private static LyricLine buildLine(Raw r, long lineEnd) {
        String text = r.text();
        if (text.isEmpty()) {
            return new LyricLine(r.start(), lineEnd, "", List.of(), false);
        }
        if (WORD_TAG.matcher(text).find()) {
            List<LyricWord> words = parseEnhanced(text, r.start(), lineEnd);
            if (!words.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                words.forEach(w -> sb.append(w.text()));
                return new LyricLine(r.start(), lineEnd, sb.toString().strip(), words, true);
            }
        }
        String clean = WORD_TAG.matcher(text).replaceAll("").strip();
        return new LyricLine(r.start(), lineEnd, clean, estimateWords(clean, r.start(), lineEnd), false);
    }

    private static List<LyricWord> parseEnhanced(String text, long lineStart, long lineEnd) {
        List<long[]> starts = new ArrayList<>();
        List<String> texts = new ArrayList<>();
        Matcher m = WORD_TAG.matcher(text);
        int prevEnd = 0;
        long prevStart = -1;
        while (m.find()) {
            if (prevStart >= 0) {
                texts.add(text.substring(prevEnd, m.start()));
            }
            prevStart = toMs(m.group(1), m.group(2), m.group(3));
            starts.add(new long[]{prevStart});
            prevEnd = m.end();
        }
        if (prevStart >= 0) {
            texts.add(text.substring(prevEnd));
        }
        List<LyricWord> words = new ArrayList<>();
        for (int i = 0; i < texts.size(); i++) {
            String t = texts.get(i);
            if (t.isBlank()) {
                continue;
            }
            long s = Math.max(starts.get(i)[0], lineStart);
            long e = i + 1 < starts.size() ? starts.get(i + 1)[0] : Math.min(lineEnd, s + 1500);
            if (e <= s) {
                e = s + 1;
            }
            words.add(new LyricWord(s, e, t.strip() + " "));
        }
        if (!words.isEmpty()) {
            LyricWord last = words.get(words.size() - 1);
            words.set(words.size() - 1, new LyricWord(last.startMs(), last.endMs(), last.text().stripTrailing()));
        }
        return words;
    }

    /** Reparte la ventana de canto de la línea entre sus palabras según su longitud. */
    static List<LyricWord> estimateWords(String text, long start, long lineEnd) {
        List<String> tokens = tokenize(text);
        if (tokens.isEmpty()) {
            return List.of();
        }
        long window = Math.min(lineEnd - start, Math.max(1200L, text.length() * 85L));
        double totalWeight = 0;
        for (String t : tokens) {
            totalWeight += weight(t);
        }
        List<LyricWord> words = new ArrayList<>();
        double acc = 0;
        for (int i = 0; i < tokens.size(); i++) {
            String t = tokens.get(i);
            double w = weight(t);
            long s = start + Math.round(window * (acc / totalWeight));
            acc += w;
            long e = start + Math.round(window * (acc / totalWeight));
            if (e <= s) {
                e = s + 1;
            }
            boolean last = i == tokens.size() - 1;
            boolean glue = !last && isCjk(t.codePointBefore(t.length())) && isCjk(tokens.get(i + 1).codePointAt(0));
            words.add(new LyricWord(s, e, (last || glue) ? t : t + " "));
        }
        return words;
    }

    private static double weight(String token) {
        return token.codePointCount(0, token.length()) + 1.0;
    }

    private static List<String> tokenize(String text) {
        List<String> out = new ArrayList<>();
        for (String part : text.split("\\s+")) {
            if (part.isEmpty()) {
                continue;
            }
            boolean cjk = part.codePoints().anyMatch(LrcParser::isCjk);
            if (cjk && part.codePointCount(0, part.length()) > 1) {
                part.codePoints().forEach(cp -> out.add(new String(Character.toChars(cp))));
            } else {
                out.add(part);
            }
        }
        return out;
    }

    private static boolean isCjk(int cp) {
        Character.UnicodeScript s = Character.UnicodeScript.of(cp);
        return s == Character.UnicodeScript.HAN || s == Character.UnicodeScript.HIRAGANA
                || s == Character.UnicodeScript.KATAKANA || s == Character.UnicodeScript.HANGUL;
    }

    private static long toMs(String min, String sec, String frac) {
        long ms = Long.parseLong(min) * 60_000L + Long.parseLong(sec) * 1000L;
        if (frac != null && !frac.isEmpty()) {
            long f = Long.parseLong(frac);
            ms += switch (frac.length()) {
                case 1 -> f * 100;
                case 2 -> f * 10;
                default -> f;
            };
        }
        return ms;
    }
}
