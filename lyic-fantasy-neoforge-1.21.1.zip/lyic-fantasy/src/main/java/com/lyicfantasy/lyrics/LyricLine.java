package com.lyicfantasy.lyrics;

import java.util.List;

/** Una línea de letra con sus palabras temporizadas. */
public record LyricLine(long startMs, long endMs, String text, List<LyricWord> words, boolean wordSynced) {

    /** Línea vacía = hueco instrumental. */
    public boolean isGap() {
        return text == null || text.isBlank();
    }
}
