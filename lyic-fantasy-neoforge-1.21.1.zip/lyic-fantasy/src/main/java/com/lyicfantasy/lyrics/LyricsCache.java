package com.lyicfantasy.lyrics;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Optional;

/** Caché en disco de letras (y de "no hay letra", con caducidad) para no repetir peticiones. */
final class LyricsCache {

    record Entry(String lrc, boolean none, String source) {
    }

    private static final long NONE_TTL_MS = 12L * 60 * 60 * 1000;

    private final Path dir;

    LyricsCache(Path dir) {
        this.dir = dir;
    }

    Optional<Entry> read(String key) {
        Path f = file(key);
        try {
            if (!Files.isRegularFile(f)) {
                return Optional.empty();
            }
            JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            boolean none = o.has("none") && o.get("none").getAsBoolean();
            long ts = o.has("ts") ? o.get("ts").getAsLong() : 0L;
            if (none && System.currentTimeMillis() - ts > NONE_TTL_MS) {
                return Optional.empty();
            }
            String lrc = o.has("lrc") ? o.get("lrc").getAsString() : "";
            String source = o.has("source") ? o.get("source").getAsString() : "cache";
            return Optional.of(new Entry(lrc, none, source));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    void write(String key, String lrc, String source) {
        store(key, lrc, false, source);
    }

    void writeNone(String key) {
        store(key, "", true, "none");
    }

    void delete(String key) {
        try {
            Files.deleteIfExists(file(key));
        } catch (IOException ignored) {
        }
    }

    private void store(String key, String lrc, boolean none, String source) {
        try {
            Files.createDirectories(dir);
            JsonObject o = new JsonObject();
            o.addProperty("lrc", lrc);
            o.addProperty("none", none);
            o.addProperty("source", source);
            o.addProperty("ts", System.currentTimeMillis());
            Files.writeString(file(key), o.toString(), StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }

    private Path file(String key) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8));
            return dir.resolve(HexFormat.of().formatHex(h, 0, 12) + ".json");
        } catch (Exception e) {
            return dir.resolve(Integer.toHexString(key.hashCode()) + ".json");
        }
    }
}
