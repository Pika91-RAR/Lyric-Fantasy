package com.lyicfantasy.lyrics;

/** Una palabra (o sílaba/carácter) con su ventana de tiempo. El texto incluye el espacio final si lo hay. */
public record LyricWord(long startMs, long endMs, String text) {
}
