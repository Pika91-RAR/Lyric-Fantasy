package com.lyicfantasy.lyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lyicfantasy.media.TrackInfo;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Optional;

/** LRCLIB (https://lrclib.net): letras sincronizadas gratuitas, sin API key. */
public final class LrclibSource implements LyricsSource {

    private static final String BASE = "https://lrclib.net/api";
    private static final String USER_AGENT = "LyicFantasy/0.1 (Minecraft NeoForge mod)";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    /** Última letra cruda encontrada (para la caché). */
    public record Found(String lrc, LyricsData data) {
    }

    @Override
    public String name() {
        return "lrclib";
    }

    @Override
    public Optional<LyricsData> fetch(TrackInfo track) throws Exception {
        return fetchRaw(track).map(Found::data);
    }

    public Optional<Found> fetchRaw(TrackInfo track) throws Exception {
        TitleCleaner.Cleaned c = TitleCleaner.clean(track.title(), track.artist());
        long durSec = track.durationMs() > 0 ? Math.round(track.durationMs() / 1000.0) : 0;

        // 1) coincidencia exacta
        StringBuilder url = new StringBuilder(BASE).append("/get?track_name=").append(enc(c.title()))
                .append("&artist_name=").append(enc(c.artist()));
        if (track.album() != null && !track.album().isBlank()) {
            url.append("&album_name=").append(enc(track.album()));
        }
        if (durSec > 0) {
            url.append("&duration=").append(durSec);
        }
        HttpResponse<String> r = get(url.toString());
        if (r.statusCode() == 200) {
            Optional<Found> f = fromObject(JsonParser.parseString(r.body()).getAsJsonObject(), track);
            if (f.isPresent()) {
                return f;
            }
        }

        // 2) búsqueda difusa
        r = get(BASE + "/search?track_name=" + enc(c.title()) + "&artist_name=" + enc(c.artist()));
        Optional<Found> best = bestOf(r, track, durSec);
        if (best.isPresent()) {
            return best;
        }
        r = get(BASE + "/search?q=" + enc((c.artist() + " " + c.title()).strip()));
        return bestOf(r, track, durSec);
    }

    private Optional<Found> bestOf(HttpResponse<String> r, TrackInfo track, long durSec) {
        if (r.statusCode() != 200) {
            return Optional.empty();
        }
        JsonElement root = JsonParser.parseString(r.body());
        if (!root.isJsonArray()) {
            return Optional.empty();
        }
        JsonArray arr = root.getAsJsonArray();
        JsonObject best = null;
        double bestDiff = Double.MAX_VALUE;
        for (JsonElement e : arr) {
            if (!e.isJsonObject()) {
                continue;
            }
            JsonObject o = e.getAsJsonObject();
            if (!hasSynced(o)) {
                continue;
            }
            double diff = 0;
            if (durSec > 0 && o.has("duration") && !o.get("duration").isJsonNull()) {
                diff = Math.abs(o.get("duration").getAsDouble() - durSec);
                if (diff > 5) {
                    continue; // otra versión/otra canción
                }
            }
            if (diff < bestDiff) {
                bestDiff = diff;
                best = o;
            }
        }
        return best == null ? Optional.empty() : fromObject(best, track);
    }

    private static boolean hasSynced(JsonObject o) {
        return o.has("syncedLyrics") && !o.get("syncedLyrics").isJsonNull()
                && !o.get("syncedLyrics").getAsString().isBlank();
    }

    private Optional<Found> fromObject(JsonObject o, TrackInfo track) {
        if (!hasSynced(o)) {
            return Optional.empty();
        }
        String lrc = o.get("syncedLyrics").getAsString();
        LyricsData data = LrcParser.parse(lrc, track.durationMs(), name());
        return data.isEmpty() ? Optional.empty() : Optional.of(new Found(lrc, data));
    }

    private static HttpResponse<String> get(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("User-Agent", USER_AGENT)
                .GET().build();
        return HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
    }

    private static String enc(String s) {
        return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8);
    }
}
