package com.lyicfantasy.render;

import com.lyicfantasy.config.LyicConfig;
import com.lyicfantasy.lyrics.LyricLine;
import com.lyicfantasy.lyrics.LyricsData;
import com.lyicfantasy.lyrics.LyricsManager;
import com.lyicfantasy.media.MediaManager;
import com.lyicfantasy.media.TrackInfo;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;

/**
 * Decide QUÉ se dibuja (líneas, posiciones relativas, tamaño y opacidad). Los renderizadores del mundo y
 * del HUD solo se encargan de CÓMO dibujarlo, así comparten lógica y animaciones.
 */
public final class LyricsPresenter {

    public enum Status { HIDDEN, LOADING, NO_LYRICS, READY }

    public record Snapshot(Status status, TrackInfo track, LyricsData data, int index, long posMs, float scroll) {
    }

    /**
     * Una línea lista para dibujar.
     * {@code slot}: posición vertical en "líneas" respecto al centro (0 = centro, positivo = abajo).
     */
    public record Spec(FormattedCharSequence text, float slot, float scale, float alpha) {
    }

    private static final float SCROLL_MS = 320f;

    private static String lastKey = "";
    private static int lastIndex = Integer.MIN_VALUE;
    private static long scrollStartNanos = 0L;

    private LyricsPresenter() {
    }

    public static Snapshot snapshot() {
        MediaManager media = MediaManager.get();
        TrackInfo track = media.track();
        if (track == null) {
            return new Snapshot(Status.HIDDEN, null, null, -1, 0, 0f);
        }
        LyricsManager lm = LyricsManager.get();
        switch (lm.state()) {
            case LOADING:
                return new Snapshot(Status.LOADING, track, null, -1, 0, 0f);
            case READY:
                break;
            default:
                return new Snapshot(Status.NO_LYRICS, track, null, -1, 0, 0f);
        }
        LyricsData data = lm.data();
        if (data == null) {
            return new Snapshot(Status.NO_LYRICS, track, null, -1, 0, 0f);
        }
        long pos = media.positionMs() + LyicConfig.OFFSET_MS.get();
        int idx = data.indexAt(pos);

        long now = System.nanoTime();
        String key = track.key();
        if (!key.equals(lastKey)) {
            lastKey = key;
            scrollStartNanos = 0L;
        } else if (idx == lastIndex + 1) {
            scrollStartNanos = now;       // avance natural de una línea -> animación
        } else if (idx != lastIndex) {
            scrollStartNanos = 0L;        // salto (seek): sin animación
        }
        lastIndex = idx;

        float scroll = 0f;
        if (scrollStartNanos != 0L) {
            float t = (now - scrollStartNanos) / 1_000_000f / SCROLL_MS;
            if (t >= 1f) {
                scrollStartNanos = 0L;
            } else {
                float r = 1f - t;
                scroll = r * r;           // ease-out cuadrático
            }
        }
        return new Snapshot(Status.READY, track, data, idx, pos, scroll);
    }

    public static List<Spec> layout(Snapshot s) {
        List<Spec> out = new ArrayList<>(4);
        int text = LyicConfig.textRgb();
        int accent = LyicConfig.accentRgb();

        if (s.status() == Status.HIDDEN) {
            return out;
        }
        if (s.status() != Status.READY) {
            if (LyicConfig.SHOW_TRACK_HEADLINE.get() && s.track() != null) {
                String h = "\u266A " + s.track().title()
                        + (s.track().artist().isBlank() ? "" : " - " + s.track().artist());
                out.add(new Spec(TextStyler.plain(h, text), 0f, 0.8f, s.status() == Status.LOADING ? 0.45f : 0.6f));
            }
            return out;
        }

        boolean neighbors = LyicConfig.SHOW_NEIGHBORS.get();
        for (int n = neighbors ? -2 : 0; n <= (neighbors ? 1 : 0); n++) {
            int i = s.index() + n;
            LyricLine line = i >= 0 && i < s.data().lines().size() ? s.data().lines().get(i) : null;
            boolean center = n == 0;
            if (line == null && !(center && s.index() < 0)) {
                continue; // fuera de rango (salvo el "♪" previo a la primera línea)
            }

            float p = n + s.scroll();
            float w = Math.max(0f, 1f - Math.abs(p));
            float scale = 0.82f + 0.55f * w;
            float alpha = 0.30f + 0.70f * w;
            if (n == -2) {
                alpha *= s.scroll();
            }
            if (n == 1) {
                alpha *= (1f - s.scroll());
            }
            if (alpha < 0.03f) {
                continue;
            }

            FormattedCharSequence seq;
            if (line == null || line.isGap()) {
                seq = TextStyler.plain("\u266A", center ? accent : text);
            } else if (center && LyicConfig.KARAOKE.get()) {
                seq = TextStyler.karaoke(line, s.posMs(), accent, text);
            } else {
                seq = TextStyler.plain(line.text(), center ? accent : text);
            }
            out.add(new Spec(seq, p, scale, Math.min(1f, alpha)));
        }
        return out;
    }
}
