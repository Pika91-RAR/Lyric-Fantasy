package com.lyicfantasy.render;

import com.lyicfantasy.LyicFantasy;
import com.lyicfantasy.config.LyicConfig;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

/** Modo HUD: las mismas líneas y animaciones, pero sobre la pantalla. */
public final class HudLyricsLayer {

    private static final float LINE_STEP = 14f;

    private HudLyricsLayer() {
    }

    public static void register(RegisterGuiLayersEvent event) {
        event.registerAboveAll(ResourceLocation.fromNamespaceAndPath(LyicFantasy.MODID, "lyrics"),
                HudLyricsLayer::render);
    }

    private static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (!LyicConfig.ENABLED.get() || LyicConfig.MODE.get() != LyicConfig.Mode.HUD
                || mc.options.hideGui || mc.player == null) {
            return;
        }
        var specs = LyricsPresenter.layout(LyricsPresenter.snapshot());
        if (specs.isEmpty()) {
            return;
        }
        Font font = mc.font;
        float scale = (float) (double) LyicConfig.SCALE.get();
        float cx = g.guiWidth() / 2f;
        float cy = g.guiHeight() - 92f * Math.max(1f, scale * 0.8f);
        boolean shadow = LyicConfig.SHADOW.get();

        for (LyricsPresenter.Spec s : specs) {
            g.pose().pushPose();
            g.pose().translate(cx, cy + s.slot() * LINE_STEP * scale, 0f);
            g.pose().scale(s.scale() * scale, s.scale() * scale, 1f);
            int a = Mth.clamp((int) (s.alpha() * 255f), 5, 255);
            g.drawString(font, s.text(), -font.width(s.text()) / 2, -font.lineHeight / 2, (a << 24) | 0xFFFFFF, shadow);
            g.pose().popPose();
        }
    }
}
