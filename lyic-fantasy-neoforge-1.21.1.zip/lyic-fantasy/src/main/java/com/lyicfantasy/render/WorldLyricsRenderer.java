package com.lyicfantasy.render;

import com.lyicfantasy.config.LyicConfig;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Dibuja la letra dentro del mundo. Tres ideas clave:
 * 1) Cada frame se calcula una posición/orientación OBJETIVO según el modo (adaptativo, frente, cielo).
 * 2) La posición y la rotación reales siguen al objetivo con suavizado exponencial (efecto flotante).
 * 3) El tamaño se escala con la distancia para mantener un tamaño aparente constante en pantalla.
 */
public final class WorldLyricsRenderer {

    private static final float LINE_STEP = 14f;

    private static Vec3 smoothPos;
    private static final Quaternionf SMOOTH_ROT = new Quaternionf();
    private static boolean rotInit;
    private static long lastNanos;
    private static ResourceKey<Level> lastDimension;

    private WorldLyricsRenderer() {
    }

    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.options.hideGui || !LyicConfig.ENABLED.get()) {
            return;
        }
        LyicConfig.Mode mode = LyicConfig.MODE.get();
        if (mode == LyicConfig.Mode.HUD) {
            return;
        }
        LyricsPresenter.Snapshot snap = LyricsPresenter.snapshot();
        var specs = LyricsPresenter.layout(snap);
        if (specs.isEmpty()) {
            return;
        }

        Camera cam = event.getCamera();
        Vec3 camPos = cam.getPosition();
        Vector3f lf = cam.getLookVector();
        Vec3 look = new Vec3(lf.x(), lf.y(), lf.z());
        Vector3f uf = cam.getUpVector();
        Vec3 up = new Vec3(uf.x(), uf.y(), uf.z());

        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 0.016f : Math.min(0.1f, (now - lastNanos) / 1_000_000_000f);
        lastNanos = now;

        // ---- 1) objetivo según el modo ---------------------------------------------------------------
        Vec3 target;
        Quaternionf targetRot = null; // null = billboard (mira a la cámara)
        double speed = LyicConfig.FOLLOW_SPEED.get();
        double lift = LyicConfig.LIFT.get();

        switch (mode) {
            case WORLD_FRONT -> {
                Vec3 p = camPos.add(look.scale(LyicConfig.FRONT_DISTANCE.get()));
                target = p.add(up.scale(lift * LyicConfig.FRONT_DISTANCE.get()));
            }
            case WORLD_SKY -> {
                target = skyPosition(mc, camPos);
                speed *= 0.4; // el cielo se mueve más despacio, da sensación de lejanía
            }
            default -> { // WORLD_ADAPTIVE
                double max = LyicConfig.MAX_DISTANCE.get();
                double min = LyicConfig.MIN_DISTANCE.get();
                BlockHitResult hit = mc.level.clip(new ClipContext(camPos, camPos.add(look.scale(max)),
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
                if (hit.getType() == HitResult.Type.BLOCK) {
                    double d = camPos.distanceTo(hit.getLocation());
                    Direction face = hit.getDirection();
                    Vec3 n = new Vec3(face.getStepX(), face.getStepY(), face.getStepZ());
                    boolean facing = look.scale(-1).dot(n) > 0.35; // evita ángulos rasantes ilegibles
                    if (LyicConfig.SURFACE_ALIGN.get() && facing && d >= min) {
                        target = hit.getLocation().add(n.scale(0.03)).add(0, lift * d, 0);
                        targetRot = rotationFacing(n.scale(-1));
                    } else {
                        double dist = Mth.clamp(d - 0.4, min, max);
                        Vec3 p = camPos.add(look.scale(dist));
                        target = p.add(up.scale(lift * dist));
                    }
                } else if (LyicConfig.SKY_FALLBACK.get()) {
                    target = skyPosition(mc, camPos);
                    speed *= 0.5;
                } else {
                    Vec3 p = camPos.add(look.scale(max));
                    target = p.add(up.scale(lift * max));
                }
            }
        }

        // ---- 2) suavizado ----------------------------------------------------------------------------
        ResourceKey<Level> dim = mc.level.dimension();
        boolean teleported = smoothPos == null || !dim.equals(lastDimension) || smoothPos.distanceToSqr(target) > 96 * 96;
        lastDimension = dim;
        double a = 1.0 - Math.exp(-speed * dt);
        smoothPos = teleported ? target : smoothPos.lerp(target, a);

        Quaternionf wantedRot = targetRot != null ? targetRot : new Quaternionf(cam.rotation());
        if (!rotInit || teleported) {
            SMOOTH_ROT.set(wantedRot);
            rotInit = true;
        } else {
            float ra = (float) (1.0 - Math.exp(-(targetRot != null ? speed : 30.0) * dt));
            SMOOTH_ROT.slerp(wantedRot, ra);
        }

        // ---- 3) dibujo -------------------------------------------------------------------------------
        double dist = camPos.distanceTo(smoothPos);
        float base = (float) (0.0075 * Math.max(dist, 0.5) * LyicConfig.SCALE.get());

        PoseStack ps = event.getPoseStack();
        ps.pushPose();
        ps.translate(smoothPos.x - camPos.x, smoothPos.y - camPos.y, smoothPos.z - camPos.z);
        ps.mulPose(SMOOTH_ROT);
        ps.scale(-base, -base, base);

        Font font = mc.font;
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        boolean shadow = LyicConfig.SHADOW.get();
        LyicConfig.DepthMode depth = LyicConfig.DEPTH_MODE.get();

        for (LyricsPresenter.Spec s : specs) {
            ps.pushPose();
            ps.translate(0f, s.slot() * LINE_STEP, 0f);
            ps.scale(s.scale(), s.scale(), 1f);
            Matrix4f m = ps.last().pose();
            float x = -font.width(s.text()) / 2f;
            float y = -font.lineHeight / 2f;

            switch (depth) {
                case OCCLUDED -> font.drawInBatch(s.text(), x, y, argb(s.alpha()), shadow, m, buffers,
                        Font.DisplayMode.NORMAL, 0, LightTexture.FULL_BRIGHT);
                case ALWAYS_VISIBLE -> font.drawInBatch(s.text(), x, y, argb(s.alpha()), shadow, m, buffers,
                        Font.DisplayMode.SEE_THROUGH, 0, LightTexture.FULL_BRIGHT);
                case GHOST -> {
                    font.drawInBatch(s.text(), x, y, argb(s.alpha() * 0.28f), false, m, buffers,
                            Font.DisplayMode.SEE_THROUGH, 0, LightTexture.FULL_BRIGHT);
                    font.drawInBatch(s.text(), x, y, argb(s.alpha()), shadow, m, buffers,
                            Font.DisplayMode.NORMAL, 0, LightTexture.FULL_BRIGHT);
                }
            }
            ps.popPose();
        }
        buffers.endBatch();
        ps.popPose();
    }

    /** Punto del cielo en la dirección horizontal en la que miras, elevado el ángulo configurado. */
    private static Vec3 skyPosition(Minecraft mc, Vec3 camPos) {
        double yaw = Math.toRadians(mc.player.getYRot());
        double el = Math.toRadians(LyicConfig.SKY_ELEVATION.get());
        double d = LyicConfig.SKY_DISTANCE.get();
        double hx = -Math.sin(yaw);
        double hz = Math.cos(yaw);
        return camPos.add(hx * Math.cos(el) * d, Math.sin(el) * d, hz * Math.cos(el) * d);
    }

    /** Rotación equivalente a una cámara que mira en la dirección {@code f} (misma fórmula que Camera#setRotation). */
    private static Quaternionf rotationFacing(Vec3 f) {
        double yawDeg = Math.toDegrees(Mth.atan2(-f.x, f.z));
        double pitchDeg = Math.toDegrees(-Math.asin(Mth.clamp(f.y, -1.0, 1.0)));
        return new Quaternionf().rotationYXZ(
                (float) Math.PI - (float) Math.toRadians(yawDeg),
                -(float) Math.toRadians(pitchDeg),
                0f);
    }

    /** Solo canal alfa; el color RGB lo aporta el estilo de cada carácter. */
    private static int argb(float alpha) {
        int a = Mth.clamp((int) (alpha * 255f), 5, 255); // alfa <= 3 se trata como opaco en Font
        return (a << 24) | 0x00FFFFFF;
    }
}
