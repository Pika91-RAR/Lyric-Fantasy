package com.lyicfantasy.render;

import com.lyicfantasy.lyrics.LyricLine;
import com.lyicfantasy.lyrics.LyricWord;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;

/** Construye el texto con color por carácter (relleno karaoke). */
public final class TextStyler {

    private TextStyler() {
    }

    public static FormattedCharSequence plain(String text, int rgb) {
        return Component.literal(text).withStyle(Style.EMPTY.withColor(rgb)).getVisualOrderText();
    }

    /** Lo ya cantado en {@code sungRgb}, lo que falta en {@code restRgb}; la palabra actual se rellena letra a letra. */
    public static FormattedCharSequence karaoke(LyricLine line, long posMs, int sungRgb, int restRgb) {
        if (line.words().isEmpty()) {
            return plain(line.text(), restRgb);
        }
        MutableComponent root = Component.empty();
        Style sung = Style.EMPTY.withColor(sungRgb);
        Style rest = Style.EMPTY.withColor(restRgb);
        for (LyricWord w : line.words()) {
            String t = w.text();
            int n;
            if (posMs >= w.endMs()) {
                n = t.length();
            } else if (posMs <= w.startMs()) {
                n = 0;
            } else {
                double frac = (double) (posMs - w.startMs()) / (double) Math.max(1L, w.endMs() - w.startMs());
                n = (int) Math.floor(frac * t.length());
            }
            if (n > 0) {
                root.append(Component.literal(t.substring(0, n)).withStyle(sung));
            }
            if (n < t.length()) {
                root.append(Component.literal(t.substring(n)).withStyle(rest));
            }
        }
        return root.getVisualOrderText();
    }
}
