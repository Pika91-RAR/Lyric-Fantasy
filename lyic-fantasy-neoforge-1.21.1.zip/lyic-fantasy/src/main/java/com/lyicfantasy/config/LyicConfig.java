package com.lyicfantasy.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Configuración de cliente (config/lyicfantasy-client.toml). También aparece en Mods > Lyic Fantasy > Config. */
public final class LyicConfig {

    public enum Mode {
        /** La letra se proyecta sobre lo que miras (o va al cielo si no hay nada). */
        WORLD_ADAPTIVE,
        /** Flota a distancia fija delante de ti, con inercia. */
        WORLD_FRONT,
        /** Fija en lo alto del cielo, siguiéndote con retraso suave. */
        WORLD_SKY,
        /** Superpuesta en pantalla, estilo subtítulos. */
        HUD;

        public Mode next() {
            Mode[] v = values();
            return v[(ordinal() + 1) % v.length];
        }
    }

    public enum DepthMode {
        /** Los bloques la tapan. */
        OCCLUDED,
        /** Los bloques la tapan, pero se intuye un fantasma tenue a través. */
        GHOST,
        /** Siempre visible, atraviesa los bloques. */
        ALWAYS_VISIBLE
    }

    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.EnumValue<Mode> MODE;
    public static final ModConfigSpec.IntValue OFFSET_MS;
    public static final ModConfigSpec.DoubleValue SCALE;

    public static final ModConfigSpec.EnumValue<DepthMode> DEPTH_MODE;
    public static final ModConfigSpec.DoubleValue MIN_DISTANCE;
    public static final ModConfigSpec.DoubleValue MAX_DISTANCE;
    public static final ModConfigSpec.DoubleValue FRONT_DISTANCE;
    public static final ModConfigSpec.BooleanValue SURFACE_ALIGN;
    public static final ModConfigSpec.BooleanValue SKY_FALLBACK;
    public static final ModConfigSpec.DoubleValue SKY_DISTANCE;
    public static final ModConfigSpec.DoubleValue SKY_ELEVATION;
    public static final ModConfigSpec.DoubleValue LIFT;
    public static final ModConfigSpec.DoubleValue FOLLOW_SPEED;

    public static final ModConfigSpec.BooleanValue KARAOKE;
    public static final ModConfigSpec.BooleanValue SHOW_NEIGHBORS;
    public static final ModConfigSpec.BooleanValue SHOW_TRACK_HEADLINE;
    public static final ModConfigSpec.BooleanValue SHADOW;
    public static final ModConfigSpec.ConfigValue<String> ACCENT_COLOR;
    public static final ModConfigSpec.ConfigValue<String> TEXT_COLOR;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.push("general");
        ENABLED = b.comment("Activa o desactiva las letras.").define("enabled", true);
        MODE = b.comment("Dónde se muestran las letras.").defineEnum("mode", Mode.WORLD_ADAPTIVE);
        OFFSET_MS = b.comment("Desfase de sincronía en ms. Positivo = la letra va más tarde; negativo = más pronto.")
                .defineInRange("offsetMs", 0, -5000, 5000);
        SCALE = b.comment("Tamaño general del texto.").defineInRange("scale", 1.0, 0.3, 4.0);
        b.pop();

        b.push("world");
        DEPTH_MODE = b.comment("Cómo interactúa con los bloques: OCCLUDED, GHOST o ALWAYS_VISIBLE.")
                .defineEnum("depthMode", DepthMode.OCCLUDED);
        MIN_DISTANCE = b.comment("[ADAPTIVE] Distancia mínima a la que se coloca la letra.")
                .defineInRange("minDistance", 1.5, 0.5, 16.0);
        MAX_DISTANCE = b.comment("[ADAPTIVE] Alcance máximo del rayo que busca superficies.")
                .defineInRange("maxDistance", 24.0, 4.0, 128.0);
        FRONT_DISTANCE = b.comment("[FRONT] Distancia fija delante de la cámara.")
                .defineInRange("frontDistance", 6.0, 1.5, 32.0);
        SURFACE_ALIGN = b.comment("[ADAPTIVE] Si miras un bloque, la letra se pega a su cara en vez de mirarte de frente.")
                .define("surfaceAlign", true);
        SKY_FALLBACK = b.comment("[ADAPTIVE] Si no hay nada que mirar (cielo/horizonte), la letra sube al cielo.")
                .define("skyFallback", true);
        SKY_DISTANCE = b.comment("[SKY] Distancia a la que flota en el cielo.")
                .defineInRange("skyDistance", 40.0, 8.0, 160.0);
        SKY_ELEVATION = b.comment("[SKY] Ángulo sobre el horizonte, en grados.")
                .defineInRange("skyElevation", 32.0, 0.0, 85.0);
        LIFT = b.comment("Cuánto se eleva el texto respecto al punto que miras (en fracción de la distancia). 0 = justo en el punto.")
                .defineInRange("lift", 0.12, -0.5, 0.6);
        FOLLOW_SPEED = b.comment("Rapidez con que la letra sigue tu mirada. Menor = más flotante/pesada.")
                .defineInRange("followSpeed", 9.0, 1.0, 30.0);
        b.pop();

        b.push("style");
        KARAOKE = b.comment("Rellena la línea actual palabra por palabra.").define("karaoke", true);
        SHOW_NEIGHBORS = b.comment("Muestra la línea anterior y la siguiente, atenuadas.").define("showNeighbors", true);
        SHOW_TRACK_HEADLINE = b.comment("Si no hay letra, muestra 'Título - Artista'.").define("showTrackHeadline", true);
        SHADOW = b.comment("Sombra del texto.").define("shadow", true);
        ACCENT_COLOR = b.comment("Color de lo ya cantado (hex #RRGGBB).")
                .define("accentColor", "#7CF2FF", o -> o instanceof String s && s.matches("#[0-9a-fA-F]{6}"));
        TEXT_COLOR = b.comment("Color del texto aún no cantado (hex #RRGGBB).")
                .define("textColor", "#FFFFFF", o -> o instanceof String s && s.matches("#[0-9a-fA-F]{6}"));
        b.pop();

        SPEC = b.build();
    }

    private LyicConfig() {
    }

    public static int accentRgb() {
        return parse(ACCENT_COLOR.get(), 0x7CF2FF);
    }

    public static int textRgb() {
        return parse(TEXT_COLOR.get(), 0xFFFFFF);
    }

    private static int parse(String hex, int fallback) {
        try {
            return Integer.parseInt(hex.substring(1), 16);
        } catch (Exception e) {
            return fallback;
        }
    }

    public static void save() {
        SPEC.save();
    }
}
