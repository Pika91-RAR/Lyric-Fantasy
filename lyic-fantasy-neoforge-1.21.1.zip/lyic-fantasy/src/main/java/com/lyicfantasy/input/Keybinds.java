package com.lyicfantasy.input;

import com.lyicfantasy.config.LyicConfig;
import com.lyicfantasy.lyrics.LyricsManager;
import com.lyicfantasy.media.MediaManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

public final class Keybinds {

    private static final String CATEGORY = "key.categories.lyicfantasy";

    private static final KeyMapping TOGGLE = new KeyMapping("key.lyicfantasy.toggle",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY);
    private static final KeyMapping CYCLE_MODE = new KeyMapping("key.lyicfantasy.cycle_mode",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY);
    private static final KeyMapping OFFSET_MINUS = new KeyMapping("key.lyicfantasy.offset_minus",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, CATEGORY);
    private static final KeyMapping OFFSET_PLUS = new KeyMapping("key.lyicfantasy.offset_plus",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, CATEGORY);

    private Keybinds() {
    }

    public static void register(RegisterKeyMappingsEvent e) {
        e.register(TOGGLE);
        e.register(CYCLE_MODE);
        e.register(OFFSET_MINUS);
        e.register(OFFSET_PLUS);
    }

    public static void onClientTick(ClientTickEvent.Post e) {
        // La canción se vigila siempre, aunque no haya jugador, para tener la letra lista al entrar.
        LyricsManager.get().onTrack(MediaManager.get().track());

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        while (TOGGLE.consumeClick()) {
            boolean v = !LyicConfig.ENABLED.get();
            LyicConfig.ENABLED.set(v);
            LyicConfig.save();
            say(mc, Component.translatable(v ? "lyicfantasy.msg.on" : "lyicfantasy.msg.off"));
        }
        while (CYCLE_MODE.consumeClick()) {
            LyicConfig.Mode m = LyicConfig.MODE.get().next();
            LyicConfig.MODE.set(m);
            LyicConfig.save();
            say(mc, Component.translatable("lyicfantasy.msg.mode", m.name()));
        }
        while (OFFSET_MINUS.consumeClick()) {
            nudge(mc, -100);
        }
        while (OFFSET_PLUS.consumeClick()) {
            nudge(mc, 100);
        }
    }

    private static void nudge(Minecraft mc, int delta) {
        int v = Math.max(-5000, Math.min(5000, LyicConfig.OFFSET_MS.get() + delta));
        LyicConfig.OFFSET_MS.set(v);
        LyicConfig.save();
        say(mc, Component.translatable("lyicfantasy.msg.offset", v));
    }

    private static void say(Minecraft mc, Component c) {
        if (mc.player != null) {
            mc.player.displayClientMessage(c, true);
        }
    }
}
