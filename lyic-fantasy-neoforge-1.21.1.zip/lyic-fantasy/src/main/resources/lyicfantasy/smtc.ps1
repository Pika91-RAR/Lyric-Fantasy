# Lyic Fantasy - lector de "Now Playing" de Windows (SMTC).
# Emite una linea JSON por iteracion. Solo ASCII: PowerShell 5.1 lee scripts sin BOM como ANSI.
param([int]$ParentPid = 0)

$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false

Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
[void][Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]

$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]

function Await($op, [Type]$type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    if ($task.Wait(2500)) { return $task.Result }
    return $null
}

$mgr = Await ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
if (-not $mgr) { exit 1 }

$ignore = 'TikTok|GDI\+|Default IME|MSCTFIME'

while ($true) {
    if ($ParentPid -gt 0 -and -not (Get-Process -Id $ParentPid)) { exit 0 }

    $out = [ordered]@{ none = $true }
    $chosen = $null
    foreach ($s in $mgr.GetSessions()) {
        if ($s.GetPlaybackInfo().PlaybackStatus -eq 'Playing') { $chosen = $s; break }
    }
    if (-not $chosen) { $chosen = $mgr.GetCurrentSession() }

    if ($chosen) {
        $props = Await ($chosen.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        $info = $chosen.GetPlaybackInfo()
        $tl = $chosen.GetTimelineProperties()
        if ($props -and $props.Title -and ($props.Title -notmatch $ignore)) {
            $playing = ($info.PlaybackStatus -eq 'Playing')
            $pos = $tl.Position.TotalMilliseconds
            if ($playing) {
                $rate = 1.0
                if ($info.PlaybackRate) { $rate = [double]$info.PlaybackRate }
                $age = ([DateTimeOffset]::UtcNow - $tl.LastUpdatedTime).TotalMilliseconds
                if ($age -gt 0 -and $age -lt 600000) { $pos += $age * $rate }
            }
            $dur = $tl.EndTime.TotalMilliseconds - $tl.StartTime.TotalMilliseconds
            if ($dur -gt 0 -and $pos -gt $dur) { $pos = $dur }
            if ($pos -lt 0) { $pos = 0 }
            $out = [ordered]@{
                title   = [string]$props.Title
                artist  = [string]$props.Artist
                album   = [string]$props.AlbumTitle
                dur     = [math]::Round($dur)
                pos     = [math]::Round($pos)
                playing = $playing
                app     = [string]$chosen.SourceAppUserModelId
            }
        }
    }

    [Console]::Out.WriteLine(($out | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
    Start-Sleep -Milliseconds 400
}
