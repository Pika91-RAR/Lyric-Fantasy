# Lyic Fantasy (NeoForge 1.21.1)

Mod **solo de cliente** que lee lo que suena en tu PC (Spotify, YouTube Music, navegador, cualquier
reproductor con "Now Playing") y muestra la letra sincronizada dentro del mundo de Minecraft.

## Modos (tecla K para alternar, /lyic mode <modo>)
| Modo | Qué hace |
|---|---|
| `world_adaptive` | Lanza un rayo desde tu mirada: si apunta a un bloque, la letra se pega a su cara (o se coloca justo delante); si no hay nada, sube al cielo. |
| `world_front` | Flota a distancia fija delante de ti, con inercia. |
| `world_sky` | Fija en lo alto, siguiéndote con retraso suave. |
| `hud` | En pantalla, estilo subtítulos. |

Interacción con bloques (`world.depthMode`): `OCCLUDED` (los bloques la tapan), `GHOST` (tapada, pero se intuye
a través) y `ALWAYS_VISIBLE`.

## Teclas y comandos
- `J` activar/desactivar · `K` cambiar modo · `[` / `]` ajustar sincronía ±100 ms
- `/lyic offset <ms>` · `/lyic mode <modo>` · `/lyic reload` · `/lyic status`
- Configuración completa en *Mods > Lyic Fantasy > Config* o `config/lyicfantasy-client.toml`

## Compilar
Requisitos: JDK 21.
```
gradle wrapper          # una sola vez, si no tienes ./gradlew
./gradlew runClient     # probar en desarrollo
./gradlew build         # JAR en build/libs/
```
Si Gradle no encuentra las versiones de `neo_version` (gradle.properties) o del plugin `net.neoforged.moddev`
(build.gradle), pon las últimas 21.1.x / 2.0.x publicadas.

## Cómo funciona
- **Música:** Windows → `smtc.ps1` (PowerShell + SMTC) lanzado por el mod; Linux → `playerctl` (experimental). macOS: pendiente.
- **Letras:** LRCLIB (gratis) con caché en `config/lyicfantasy/cache/`. Soporta LRC estándar y por palabra; si no trae
  tiempos por palabra, los estima.
- **Sincronía:** interpolación local entre muestras + corrección suave + offset ajustable.
- **Render:** posición y rotación objetivo por modo, suavizado exponencial, tamaño aparente constante por distancia.

## Estructura
```
lyrics/   LrcParser · LrclibSource · LyricsCache · LyricsManager · TitleCleaner
media/    MediaManager · WindowsSmtcProvider · LinuxPlayerctlProvider
render/   LyricsPresenter · TextStyler · WorldLyricsRenderer · HudLyricsLayer
config/   LyicConfig
input/    Keybinds        command/  LyicCommand
```
Para añadir otra fuente de letras: implementa `LyricsSource` y encadénala en `LyricsManager`.
Para otro sistema operativo: implementa `MediaProvider` y selecciónalo en `MediaManager.start()`.
